document.getElementById("review-btn").onclick = function() {
  document.getElementById("review-section").scrollIntoView({ 
    behavior: 'smooth' 
  });
}